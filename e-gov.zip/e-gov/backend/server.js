const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Koneksi ke MongoDB lokal
mongoose.connect("mongodb://localhost:27017/egov", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log("MongoDB Connected")).catch(console.error);

// Skema pengajuan layanan
const PengajuanSchema = new mongoose.Schema({
  nama: String,
  nik: String,
  alamat: String,
  layanan: String,
  deskripsi: String,
  status: { type: String, default: "Diproses" },
  user: String,
});

const Pengajuan = mongoose.model("Pengajuan", PengajuanSchema);

// Skema pengguna
const UserSchema = new mongoose.Schema({
  username: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['admin', 'warga'], default: 'warga' }
});

const User = mongoose.model("User", UserSchema);

// Endpoint GET semua pengajuan
app.get("/pengajuan", async (req, res) => {
  try {
    const data = await Pengajuan.find();
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Terjadi kesalahan saat mengambil data pengajuan." });
  }
});

// Endpoint POST pengajuan baru
app.post("/pengajuan", async (req, res) => {
  const { nama, nik, alamat, layanan, user } = req.body;

  if (!nama || !nik || !alamat || !layanan || !user) {
    return res.status(400).json({ success: false, message: "Data tidak lengkap. Pastikan semua field terisi." });
  }

  try {
    const newData = new Pengajuan(req.body);
    await newData.save();
    res.json({ success: true, message: "Pengajuan berhasil dikirim." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Terjadi kesalahan saat menyimpan data pengajuan." });
  }
});

// Endpoint PUT update status pengajuan
app.put("/pengajuan/:id", async (req, res) => {
  const { status } = req.body;

  if (!status) {
    return res.status(400).json({ success: false, message: "Status harus diisi." });
  }

  try {
    const updated = await Pengajuan.findByIdAndUpdate(req.params.id, { status }, { new: true });

    if (!updated) {
      return res.status(404).json({ success: false, message: "Pengajuan dengan ID tersebut tidak ditemukan." });
    }

    res.json({ success: true, message: "Status pengajuan berhasil diperbarui." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Terjadi kesalahan saat memperbarui status." });
  }
});

// Endpoint POST registrasi pengguna baru
app.post("/register", async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ success: false, message: "Username dan password harus diisi." });
  }

  try {
    const existing = await User.findOne({ username });
    if (existing) {
      return res.status(400).json({ success: false, message: "Username sudah digunakan." });
    }

    const user = new User({ username, password });
    await user.save();
    res.json({ success: true, message: "Registrasi berhasil. Silakan login." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Terjadi kesalahan saat registrasi." });
  }
});

// Endpoint POST login pengguna
app.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username, password });
    if (!user) {
      return res.status(401).json({ success: false, message: "Username atau password salah." });
    }

    res.json({
      success: true,
      user: {
        username: user.username,
        role: user.role,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Login gagal." });
  }
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: "Terjadi kesalahan pada server." });
});

// Jalankan server
app.listen(3000, () => {
  console.log("Server berjalan di http://localhost:3000");
});
