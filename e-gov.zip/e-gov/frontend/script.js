let currentUser = null;

function login(username, password) {
  if (username === "admin" && password === "admin123") {
    currentUser = { username: "admin", role: "admin" };
    alert("Login berhasil sebagai admin");
    renderApp();
    return;
  }

  // Login warga ke backend
  fetch("http://localhost:3000/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        currentUser = data.user;
        alert("Login berhasil sebagai warga");
        renderApp();
      } else {
        alert(data.message);
      }
    });
}

function register(form) {
  const username = form.username.value;
  const password = form.password.value;

  fetch("http://localhost:3000/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password, role: "warga" })
  })
    .then(res => res.json())
    .then(data => {
      alert(data.message);
      if (data.success) {
        renderApp(); // kembali ke login
      }
    });
}

function logout() {
  currentUser = null;
  renderApp();
}

function submitService(form) {
  const data = {
    nama: form.nama.value,
    nik: form.nik.value,
    alamat: form.alamat.value,
    layanan: form.layanan.value,
    deskripsi: form.deskripsi.value,
    status: "Diproses",
    user: currentUser.username
  };

  fetch("http://localhost:3000/pengajuan", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  }).then(() => {
    alert("Pengajuan berhasil dikirim!");
    form.reset();
    renderApp();
  });
}

function updateStatus(id, newStatus) {
  fetch(`http://localhost:3000/pengajuan/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status: newStatus }),
  }).then(() => {
    alert("Status layanan diperbarui.");
    renderApp();
  });
}

function renderApp() {
  const app = document.getElementById("app");

  if (!currentUser) {
    app.innerHTML = `
      <h2>Login</h2>
      <input id="username" placeholder="Username" />
      <input id="password" type="password" />
      <button onclick="login(
        document.getElementById('username').value,
        document.getElementById('password').value
      )">Login</button>
      <p>Belum punya akun warga?</p>
      <button onclick="renderRegister()">Daftar</button>
    `;
    return;
  }

  let content = `
    <h2>Halo, ${currentUser.username} (${currentUser.role})</h2>
    <button onclick="logout()">Logout</button>
  `;

  fetch("http://localhost:3000/pengajuan")
    .then(res => res.json())
    .then(data => {
      const userSubmissions = data.filter(s => s.user === currentUser.username);

      if (currentUser.role === "warga") {
        content += `
          <h3>Form Pengajuan Layanan</h3>
          <form onsubmit="event.preventDefault(); submitService(this);">
            <input name="nama" placeholder="Nama" required />
            <input name="nik" placeholder="NIK" required />
            <input name="alamat" placeholder="Alamat" required />
            <select name="layanan" required>
              <option value="">-- Pilih Layanan --</option>
              <option value="Pengajuan KTP">Pengajuan KTP</option>
              <option value="Pengajuan KK">Pengajuan KK</option>
              <option value="Surat Domisili">Surat Domisili</option>
              <option value="Izin Usaha">Izin Usaha</option>
            </select>
            <input name="deskripsi" placeholder="Deskripsi (opsional)" />
            <button type="submit">Kirim Pengajuan</button>
          </form>

          <h3>Daftar Pengajuan Saya</h3>
          <ul>
            ${userSubmissions.map(s => `
              <li><strong>${s.layanan}</strong> - Status: ${s.status}</li>
            `).join("")}
          </ul>
        `;
      }

      if (currentUser.role === "admin") {
        content += `
          <h3>Manajemen Pengajuan</h3>
          <ul>
            ${data.map(s => `
              <li>
                <strong>${s.nama}</strong> (${s.layanan})<br />
                NIK: ${s.nik}<br />
                Alamat: ${s.alamat}<br />
                Deskripsi: ${s.deskripsi}<br />
                Status: <strong>${s.status}</strong><br />
                <button onclick="updateStatus('${s._id}', 'Selesai')">Tandai Selesai</button>
              </li>
            `).join("")}
          </ul>
        `;
      }

      app.innerHTML = content;
    });
}

function renderRegister() {
  document.getElementById("app").innerHTML = `
    <h2>Form Registrasi Warga</h2>
    <form onsubmit="event.preventDefault(); register(this);">
      <input name="username" placeholder="Username" required />
      <input name="password" type="password" placeholder="Password" required />
      <button type="submit">Daftar</button>
    </form>
    <p>Sudah punya akun? <button onclick="renderApp()">Login di sini</button></p>
  `;
}

document.addEventListener("DOMContentLoaded", renderApp);
